using UnityEngine;
using Voss.Audio;
using Voss.Core;
using Voss.UI;

namespace Voss.Player
{
    /// <summary>Minimal walk + look controller. No run, jump or crouch by design.</summary>
    [RequireComponent(typeof(CharacterController))]
    public class FirstPersonController : MonoBehaviour
    {
        [SerializeField] private Transform cameraPivot;
        [SerializeField] private float moveSpeed = 2.6f;
        [SerializeField] private float lookSensitivity = 2.0f;
        [SerializeField] private float maxPitch = 85f;
        [SerializeField] private bool movementEnabled = true;
        [SerializeField] private bool lookEnabled = true;
        [SerializeField] private float footstepInterval = 0.55f;

        private CharacterController controller;
        private float pitch;
        private float yaw;
        private float verticalVelocity;
        private float stepTimer;
        private bool controlLocked;

        public Transform CameraPivot => cameraPivot;
        public bool MovementEnabled { get => movementEnabled; set => movementEnabled = value; }
        public bool LookEnabled { get => lookEnabled; set => lookEnabled = value; }

        private void Awake()
        {
            controller = GetComponent<CharacterController>();
            if (cameraPivot == null && Camera.main != null && Camera.main.transform.IsChildOf(transform))
                cameraPivot = Camera.main.transform;
            yaw = transform.eulerAngles.y;
            if (cameraPivot != null) pitch = cameraPivot.localEulerAngles.x;
            if (pitch > 180f) pitch -= 360f;
        }

        /// <summary>Hard lock used by cinematics. Independent of UI modal state.</summary>
        public void SetControlLocked(bool locked) { controlLocked = locked; }

        public void Teleport(Vector3 position, float yawDegrees)
        {
            controller.enabled = false;
            transform.position = position;
            yaw = yawDegrees;
            transform.rotation = Quaternion.Euler(0f, yaw, 0f);
            controller.enabled = true;
        }

        private void Update()
        {
            var ui = UIManager.Instance;
            bool blocked = controlLocked || (ui != null && ui.BlocksGameplay);

            if (!blocked && lookEnabled)
            {
                Vector2 look = VossInput.LookDelta() * lookSensitivity;
                yaw += look.x;
                pitch = Mathf.Clamp(pitch - look.y, -maxPitch, maxPitch);
                transform.rotation = Quaternion.Euler(0f, yaw, 0f);
                if (cameraPivot != null) cameraPivot.localRotation = Quaternion.Euler(pitch, 0f, 0f);
            }

            Vector3 move = Vector3.zero;
            if (!blocked && movementEnabled)
            {
                Vector2 input = VossInput.Move();
                move = (transform.right * input.x + transform.forward * input.y) * moveSpeed;
            }

            if (controller.isGrounded) verticalVelocity = -1f;
            else verticalVelocity += Physics.gravity.y * Time.deltaTime;
            move.y = verticalVelocity;
            controller.Move(move * Time.deltaTime);

            HandleFootsteps(move);
        }

        private void HandleFootsteps(Vector3 move)
        {
            var planar = new Vector3(move.x, 0f, move.z);
            if (planar.sqrMagnitude < 0.1f || !controller.isGrounded) { stepTimer = footstepInterval * 0.5f; return; }
            stepTimer -= Time.deltaTime;
            if (stepTimer <= 0f)
            {
                stepTimer = footstepInterval;
                GameManager.Instance?.Audio.Play(SfxId.Footstep, 0.35f);
            }
        }
    }
}
