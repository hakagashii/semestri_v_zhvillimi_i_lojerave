using UnityEngine;
using Voss.Core;
using Voss.Player;
using Voss.Interaction;
using Voss.UI;

namespace Voss.Puzzles
{
    /// <summary>
    /// One exhibit in the Perception gallery: a real object and its "reflection" behind a mirror pane.
    /// Correct exhibits use a mirrored copy; the impossible one uses an un-mirrored copy, so its
    /// left-right relationship is physically wrong. The player selects the mirror pane itself.
    /// </summary>
    public class MirrorDisplay : MonoBehaviour, IInteractable
    {
        [SerializeField] private string displayId;
        [SerializeField] private bool isImpossible;
        [SerializeField] private Transform reflectionRoot;
        [SerializeField] private Renderer mirrorRenderer;
        [SerializeField] private PerceptionPuzzle puzzle;

        private Material mirrorMaterial;
        private bool selectable = true;

        public string DisplayId => displayId;
        public bool IsImpossible => isImpossible;

        public void Configure(string id, bool impossible, Transform reflection, Renderer mirror, PerceptionPuzzle owner)
        {
            displayId = id;
            isImpossible = impossible;
            reflectionRoot = reflection;
            mirrorRenderer = mirror;
            puzzle = owner;
        }

        private Material MirrorMaterial
        {
            get
            {
                if (mirrorMaterial == null && mirrorRenderer != null) mirrorMaterial = mirrorRenderer.material;
                return mirrorMaterial;
            }
        }

        public string GetInteractionPrompt() => selectable ? "Select this reflection" : string.Empty;
        public bool CanInteract() => selectable && puzzle != null && !puzzle.IsSolved;

        public void Interact(PlayerInteractor player)
        {
            var ui = UIManager.Instance;
            if (ui == null || puzzle == null) return;
            ui.Choice.Open("THE IMPOSSIBLE REFLECTION",
                $"Declare the reflection of the {displayId} physically impossible?",
                new[] { "YES — THIS ONE", "NO — KEEP OBSERVING" },
                i =>
                {
                    ui.Choice.Close();
                    if (i == 0) puzzle.Select(this);
                }, true, null);
        }

        public void SetSelectable(bool value) { selectable = value; }

        public void SetReflectionVisible(bool visible)
        {
            if (reflectionRoot != null) reflectionRoot.gameObject.SetActive(visible);
        }

        public void SetMirrorGlow(Color color, float intensity)
        {
            var m = MirrorMaterial;
            if (m == null) return;
            if (intensity > 0f)
            {
                m.EnableKeyword("_EMISSION");
                m.SetColor("_EmissionColor", color * intensity);
            }
            else
            {
                m.SetColor("_EmissionColor", Color.black);
            }
        }

        public void SetMirrorOpaqueBlack()
        {
            var m = MirrorMaterial;
            if (m == null) return;
            m.SetColor("_EmissionColor", Color.black);
            m.SetColor("_BaseColor", new Color(0.01f, 0.01f, 0.01f, 1f));
            m.SetColor("_Color", new Color(0.01f, 0.01f, 0.01f, 1f));
            m.SetFloat("_Smoothness", 0.1f);
            m.SetFloat("_Metallic", 0f);
        }
    }
}
