# THE VOSS EXPERIMENT

First-person 3D escape room, Unity URP, keyboard + mouse. A complete, playable vertical slice:
invitation → laboratory (PERCEPTION, REASON, MEMORY) → the real final test → the empty theatre.

Everything the game needs is generated from code: the four scenes, the materials, the UI and the
placeholder audio. No prefabs, no paid assets, no manual scene wiring.

---

## 1. Setup (about five minutes)

1. **Create a project**: Unity Hub → New Project → **3D (URP)** template.
   Unity **2022.3 LTS** or **Unity 6** (the code uses `FindFirstObjectByType`, available from 2022.2).
2. **Copy** this repository's `Assets/` folder into the new project's `Assets/` folder
   (merge with the template's existing `Assets/`; nothing is overwritten).
3. Wait for scripts to compile. Packages required are all in the URP template already:
   `com.unity.render-pipelines.universal`, `com.unity.ugui`, and optionally `com.unity.inputsystem`.
4. In the menu bar choose **Voss → Build All Scenes**.
   This creates `Assets/Scenes/00_MainMenu … 03_EmptyTheatre`, `Assets/VossGenerated/Materials`,
   and registers the scenes in **Build Settings** in play order.
5. Open `00_MainMenu` (the builder opens it for you) and press **Play**.

### Input handling
The project compiles under either input backend
(`Edit → Project Settings → Player → Active Input Handling`):

* **Input Manager (Old)** or **Both** – works out of the box.
* **Input System Package (New)** – also works; `VossInput` switches on `ENABLE_INPUT_SYSTEM`
  and the UI uses `InputSystemUIInputModule` automatically.

### Optional: real audio
**Voss → Create Audio Library Asset (Resources)** makes `Assets/Resources/VossAudioLibrary.asset`
with one slot per sound and music cue. Any slot left empty keeps its procedural placeholder.

### Build
File → Build Settings → PC, Mac & Linux Standalone → Build. Scenes are already listed in order.

---

## 2. Controls

| Action | Input |
|---|---|
| Move | W A S D / arrow keys |
| Look | Mouse |
| Interact / select | **E** or left click |
| Examine mode: rotate object | hold left mouse and drag |
| Back / close / leave examine mode | **Esc** or right click |
| Evidence review | **Tab** |
| Pause menu (Resume / Restart / Main Menu) | **Esc** when nothing is open |

No run, jump or crouch – by design.

---

## 3. Walkthrough (spoilers – for QA)

1. **Invitation** – open the envelope, examine the ticket (rotate it; the back carries Voss's message).
   The number **7314** is shown and never explained. Leaving examine mode goes to the laboratory.
2. **Laboratory entrance** – step out of the elevator; it seals, lights go red, the terminal activates.
3. **PERCEPTION** – five exhibits, each with a "reflection" behind a glass pane. The **Plant**'s
   reflection leans the wrong way (left-right flipped). Select its mirror → YES. Wrong exhibit = −1 attempt.
   Reward sequence ends with a cabinet opening: take the **READ** card.
4. Back in the hall, a silhouette walks around the far east corner (once). The corridor is empty;
   the wall reads *DID YOU SEE ME? / OR DID YOU EXPECT TO?*
5. **REASON** – MASK+MASK=10, MASK+KEY=8, KEY+BLACK BOX=7 → Black Box = **4**. Enter it on the
   answer terminal. The scale settles, the box opens: no key, a **BACKWARDS** card.
6. **MEMORY door keypad** – *What number did you see before entering?* → **7314**. Wrong answers
   cost nothing and point you to the evidence (Tab shows the ticket).
7. **MEMORY** – the terminal: *What was the first thing I gave you?* READ + BACKWARDS + 7314 → **4137**.
   Fake ending (green light, music, EXPERIMENT COMPLETE), then: *YOU SOLVED THE PUZZLES. BUT YOU STILL BELIEVE THE ILLUSION.*
8. **The real final test** – all rooms illuminate with their principle. In the hall, use the
   **performance screen** (Play / Pause / frames / Change Camera). Camera B shows Voss stepping into
   darkness while a projected silhouette fills the chamber. Answer the question terminal: **He Never Entered**
   (wrong answers do not cost attempts; they hint at the other camera).
9. **Final reveal** – black screen, applause, Voss's recording. The final exit (west wall) opens.
10. **Empty theatre** – walk to the stage; a silhouette appears in the glass and is gone when you
    look back; the projector plays the last recording; *EXPERIMENT 001 — COMPLETE*; exit east.

Five attempts are shared by the three room puzzles. At zero: **EXPERIMENT FAILED / You accepted the illusion**,
with Restart Experiment / Return to Main Menu.

---

## 4. Project layout

```
Assets/
  Editor/                 Scene generators (menu: Voss)
    VossSceneBuilder.cs   Menu items, scene creation, build settings
    VossBuildKit.cs       Materials, primitives, walls, 3D text, lights, player rig
    MainMenuBuilder.cs / InvitationBuilder.cs / LaboratoryBuilder.cs / TheatreBuilder.cs
  Scripts/
    Core/        GameEnums, GameState, GameFlags, GameManager, AttemptManager, SceneTransitionManager, VossInput
    UI/          UIManager (code-built canvas), UIFactory, KeypadPanel, ChoicePanel, EvidencePanel, VideoControlsPanel
    Player/      FirstPersonController, PlayerInteractor, InspectionController
    Interaction/ IInteractable, InspectableObject, DoorController, DoorSealTrigger, EvidencePickup,
                 PlayerTriggerZone, RelayInteractable, BlackBoxController
    Puzzles/     IPuzzle/IResettable, PuzzleBase, PerceptionPuzzle, MirrorDisplay, ReasonPuzzle,
                 BalanceScaleController, KeypadController, MemoryDoorController, MemoryPuzzle,
                 TerminalController, PuzzleManager
    Narrative/   EvidenceItem, EvidenceManager, SubtitleController, MainMenuController, InvitationSequence,
                 LabEntranceSequence, VossSilhouetteEvent, VideoInvestigationController,
                 FinalInvestigationController, FinalQuestionTerminal, FinalRevealController,
                 SceneExitTrigger, TheatreEndingController, GameRestartController
    Audio/       AudioManager, AudioLibrary (ScriptableObject), ProceduralAudio
Docs/
  SCENE_ARCHITECTURE.md   Scene hierarchies, coordinates, data flow
  PLACEHOLDER_ASSETS.md   Every graybox placeholder and what should replace it
  QA_CHECKLIST.md         Acceptance tests
```

### Architecture in one paragraph
`GameManager` self-bootstraps before the first scene (`RuntimeInitializeOnLoadMethod`) and owns the
persistent services: `GameState` (pure data + events), `AttemptManager`, `SceneTransitionManager`,
`EvidenceManager`, `AudioManager`, `SubtitleController`, and the code-built `UIManager`.
Scenes contain only world objects. Puzzles derive from `PuzzleBase` (pure `Evaluate`, idempotent
`Submit`, attempt deduction, events) and keep their logic in static classes
(`ReasonPuzzleLogic`, `MemoryPuzzleLogic`) so it is testable without visuals. Doors and lights react
to `GameState` events through `GameFlag`s, so nothing polls and nothing is hard-wired by name.

### Replacing placeholders
Every generated object is named after its role (`Exhibit_Plant`, `BalanceScale`, `PerformanceScreen`, …).
Swap the primitive children for real meshes and keep the component that carries the behaviour.
See `Docs/PLACEHOLDER_ASSETS.md`.
