# QA Checklist

Run from a fresh **Build All Scenes**, playing from `00_MainMenu`. Tick each line.

## Launch and menu
- [ ] Game opens on the main menu with the camera drifting around the chamber; cursor visible.
- [ ] BEGIN EXPERIMENT fades to black and loads the invitation; cursor locked.
- [ ] QUIT exits the player (stops Play mode in the editor).

## Invitation
- [ ] Envelope prompt "Open envelope"; E opens the flap and the ticket rises; "Added to evidence" appears.
- [ ] "Examine ticket" brings the ticket in front of the camera; drag rotates; the back reads *You watched me disappear. Now find out how.*
- [ ] Front shows VOSS / PRIVATE PERFORMANCE / **7314**. Nothing explains the number.
- [ ] Esc / right click ends examine mode and the scene fades to the laboratory.
- [ ] Tab is **not** available here (evidence disabled).

## Laboratory entrance
- [ ] Elevator doors open after ~1 s; walking out seals them (lock sound), lights go red, monitor types the five lines, attempts shows 5/5.
- [ ] Cold light returns after ~7 s; Voss line plays. Tab now opens evidence (ticket present).
- [ ] REASON door: "Locked" + *Sealed. Complete PERCEPTION first.* MEMORY door: *Sealed. Use the keypad…*; keypad says *Sealed. REASON has not been completed.*
- [ ] Final exit (west): "Locked", no attempt cost. Trying locked doors never changes the attempt count.

## PERCEPTION
- [ ] Door opens on E; crossing the corridor seals it (Locked, *Sealed. The test is not finished.*).
- [ ] Each exhibit's prop can be inspected with a note; the clock shows 7:14; the portrait inscription is readable.
- [ ] Only the **Plant**'s reflection leans the opposite way. Selecting another mirror → YES costs one attempt, red pulse, *You looked. You did not observe.*
- [ ] Selecting the Plant → lights off, panes glow one by one, reflections vanish, Plant pane turns black, cabinet door drops, READ card appears.
- [ ] Taking READ adds it to evidence. Interacting with mirrors afterwards does nothing (no further deductions).
- [ ] The door is unsealed and opens from inside.

## Silhouette
- [ ] Leaving PERCEPTION the first time: music drops, a figure walks across the east alcove and turns the corner.
- [ ] The alcove is empty; the wall shows *DID YOU SEE ME? / OR DID YOU EXPECT TO?* Re-entering the trigger never replays it.
- [ ] Entering the trigger zone **before** solving PERCEPTION does not consume the event.

## REASON
- [ ] Door now opens; room seals behind you. Equation board shows the three equations.
- [ ] Mask and key are inspectable. Black Box: "Open" → *Locked. The balance decides…*, no attempt cost.
- [ ] Keypad: wrong value → *AN ASSUMPTION COSTS YOU*, −1 attempt, red pulse, keypad stays open. Clear/Esc work. Empty submit is rejected without cost.
- [ ] **4** → ACCEPTED, scale settles level, box opens itself, BACKWARDS card revealed, three Voss lines.
- [ ] Keypad afterwards: *The mechanism has already accepted its answer.* No deduction.

## MEMORY door
- [ ] Keypad asks for the number; wrong answer does **not** change attempts and says to review evidence.
- [ ] Tab shows the ticket (front/back). **7314** → REMEMBERED, door opens. Keypad afterwards is idle.

## MEMORY
- [ ] Room is nearly empty; READ and BACKWARDS displays inspectable; terminal types the three lines then opens the keypad.
- [ ] Wrong code → *Look backward.*, −1 attempt. **4137** → CODE ACCEPTED, green light, resolving music, EXPERIMENT COMPLETE.
- [ ] ~6 s later: music cuts, lights return, *YOU SOLVED THE PUZZLES. / BUT YOU STILL BELIEVE THE ILLUSION.* The exit does **not** open.

## The real final test
- [ ] All three rooms are lit with their principle text; MEMORY door opens; *THE REAL FINAL TEST* appears.
- [ ] Performance screen shows the reconstruction; PLAY advances frames; PAUSE, < FRAME, FRAME > work; CHANGE CAMERA switches to the side angle and captions change.
- [ ] Camera B visibly shows Voss leaving sideways while a flat silhouette stands in the chamber; blackout frames are dark.
- [ ] Final question: Hidden Tunnel / Secret Door / Trap Floor → Voss hint, **no attempt cost**. He Never Entered → fade to black.

## Final reveal and exit
- [ ] Applause, projector, the eleven Voss lines in order, then fade back in; EXIT sign lit; west door open; ending music.
- [ ] Walking into the vestibule loads the theatre.

## Theatre
- [ ] Spawn facing the stage; approaching raises the stage lights over 5 s.
- [ ] On the stage front, a silhouette appears in the glass; looking away removes it; looking back finds nothing.
- [ ] Projector plays the four final lines; EXIT sign lights; *EXPERIMENT 001 — COMPLETE* on screen and above the stage; east door opens.
- [ ] Walking out: fade, THE VOSS EXPERIMENT / YOU DID NOT FIND VOSS. / YOU FOUND THE TRUTH., return to main menu.

## Attempts and failure
- [ ] Attempts are shared: e.g. 2 wrong in PERCEPTION + 2 wrong in REASON + 1 wrong in MEMORY = failure.
- [ ] At 0: EXPERIMENT FAILED / You accepted the illusion; keypads/mirrors no longer accept input; Restart and Main Menu work.
- [ ] Attempt count never goes below 0 and never exceeds 5.

## Restart / robustness
- [ ] Esc pause menu (when nothing else is open): Resume / Restart / Main Menu. Esc does not open it while examining or when a panel is open.
- [ ] Restart from any point returns to the invitation with 5 attempts, no evidence, all doors locked as at the start, silhouette event re-armed.
- [ ] Opening `02_VossLaboratory` directly in the editor and pressing Play works (runtime bootstraps, fade clears, status becomes Playing).
- [ ] No console errors during a full run. Doors never stay half open; the player is never trapped.
- [ ] Both input backends: Input Manager and Input System (Project Settings → Player → Active Input Handling).
