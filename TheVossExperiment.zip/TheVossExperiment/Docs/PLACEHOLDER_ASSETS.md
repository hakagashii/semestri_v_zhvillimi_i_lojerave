# Placeholder Assets

Everything in the game is graybox built from primitives, generated materials, legacy 3D text and
procedural audio. This list names each placeholder, where it lives, and what it should become.
When replacing geometry, keep the parent GameObject and its component; swap or add mesh children.

## Materials (`Assets/VossGenerated/Materials`, URP Lit unless noted)
| Material | Used for | Replace with |
|---|---|---|
| M_Floor, M_Wall, M_Ceiling | laboratory shell | concrete / riveted black steel, aged plaster for the theatre |
| M_BlackMetal | doors, pedestals, columns, elevator | blackened iron with wear |
| M_Brass | trims, frames, scale, seal, keypads | aged brass, fingerprints |
| M_Glass, M_DarkGlass, M_MirrorPane (transparent) | chambers, mirror panes | real glass shader; mirror panes could become planar reflections (render-texture) |
| M_Card, M_Paper | clue cards, ticket, clock face | printed card textures (READ / BACKWARDS / ticket art) |
| M_Silhouette | Voss figures | keep near-black, add subtle rim light |
| M_Screen | monitors, performance screen frame | CRT / phosphor emissive screen |
| M_Projection (transparent) | projected silhouette in the diorama | soft-edged projected silhouette texture |
| M_Velvet, M_Wood | theatre curtains, seats, stage, table | velvet with folds, worn stage boards |
| M_SignRed / M_SignGreen (emissive) | EXIT signs, elevator lamp | emissive sign textures |
| M_Dust (particles) | theatre dust | soft round dust sprite |

## Characters
| Placeholder | Where | Replace with |
|---|---|---|
| VossSilhouette (capsule + cylinder hat) | SilhouetteCorridor, GlassChamber (theatre) | rigged silhouette with walk cycle; keep it unlit-black |
| VossFigure (same) | PerformanceDiorama | same model, scaled to the diorama |
| Head/eyes spheres | Exhibit_VossPortrait | painted portrait texture (eyes looking slightly away) |

## Props
| Placeholder | Scene object | Replace with |
|---|---|---|
| Envelope (boxes), WaxSeal (cylinder + "V") | 01 Envelope | black paper envelope, metallic wax seal mesh |
| VossTicket (box + 3D text) | 01 VossTicket | aged ticket mesh with front/back textures (7314 must stay legible) |
| Elevator (boxes) | 02 Entrance/Elevator | industrial cage elevator, sliding doors |
| ExperimentTerminal (box + text) | 02 Entrance | large CRT monitor; keep `TerminalController` on it |
| Door panels (2 × 3 boxes) | Door_* | heavy steel sliding doors; `DoorController.panel` must stay the moving part |
| Exhibit props (clock, portrait, statue, plant, L-sculpture) | Exhibit_* / Object / Prop | real props. Keep the asymmetry: the impossible reflection depends on a visible left/right feature |
| MirrorPane | Exhibit_* | real mirror look (reflection probe or planar reflection); keep the collider |
| HiddenREADCompartment | PERCEPTIONRoom | brass wall cabinet; `CompartmentDoor` slides down 0.9 m |
| BalanceScale | REASONRoom | antique balance; `BeamPivot` must rotate about Z |
| Mask / Key | BalanceScale/BeamPivot | theatrical mask, ornate key |
| BlackBox | REASONRoom | lacquered black box; `LidPivot` rotates about X |
| EquationDisplay | REASONRoom | chalk board or engraved brass plate |
| AnswerTerminal / MemoryDoorKeypad / FinalTerminal | 02 | brass keypads and a terminal with CRT; keep the colliders |
| READDisplay / BACKWARDSDisplay | MEMORYRoom | framed cards under glass |
| PerformanceScreen (quad) | 02 Entrance | the quad receives a RenderTexture at runtime; any mesh with UVs 0–1 works |
| PerformanceDiorama | 02 (y −60) | a proper miniature stage; keep `DarkCurtain` between Camera A and the wings |
| Theatre seats, curtains, stage, projector | 03 | real theatre set dressing; keep trigger zones |
| GlassChamber (03) | stage | hero asset – the original chamber, scratched glass, brass fittings |

## Text
All in-world text is legacy `TextMesh` (`VossBuildKit.Text3D`). Replace with TextMeshPro or textured
signage; the runtime only writes to `TerminalController.screen`, `VideoInvestigationController.caption`,
`FinalQuestionTerminal.screen` and `TheatreEndingController.completeSign` (all `TextMesh`). To move those to
TMP, change the field type and the `.text` assignments in those four scripts.

## UI
Built in code by `UIFactory` with the built-in `LegacyRuntime.ttf`. Replace the font via
`UIFactory.DefaultFont` and colours in `UIFactory` constants; or rebuild the panels with TMP.

## Audio (`Voss → Create Audio Library Asset`)
| SfxId | Placeholder | Needed |
|---|---|---|
| DoorLock, DoorOpen, MetalMechanism, Elevator | synthesized noise/sine | heavy lock bolt, sliding steel, gear clunk, lift motor |
| TerminalActivate, Click, PowerDown | synthesized | CRT power-on, key click, power-down whine |
| Reject, Confirm | synthesized | low mechanical rejection, soft chime |
| MirrorMechanism, BlackBoxOpen | synthesized | glass hum + ratchet, lacquered lid |
| Projector, Applause, Footstep, Paper | synthesized | 16 mm projector, distant audience, concrete footsteps, card handling |
| VossVoice | low tone cue | **Elias Voss voice-over** for every `VossSays` line (see `FinalRevealController.VossDialogue`, `TheatreEndingController.FinalDialogue`, and inline lines in the puzzles) |
| Music: Drone, Resolve, Ending | sine drones | minimal psychological score: low drone, a false resolution, an ending theme |

## Lighting / post
Realtime point and spot lights only, no baking. For the atmosphere pass: bake the shells, keep the
feedback lights realtime, add a URP Volume with mild vignette, film grain and colour grading (no bloom excess).
