# Scene Architecture

All scenes are produced by `Voss → Build All Scenes`. Positions below are world units (metres).
Y = 0 is the floor everywhere. The player stands 1.8 m tall with the camera at 1.6 m.

## Persistent runtime (not in any scene)

Created by `GameManager.Bootstrap()` before the first scene loads:

```
[VossRuntime]   GameManager, AttemptManager, SceneTransitionManager, EvidenceManager, AudioManager (+8 AudioSources), SubtitleController
[VossUI]        UIManager → Canvas (sort 100): Crosshair, Prompt, Subtitle, Attempts, MessageBackdrop,
                KeypadPanel, EvidencePanel, ChoicePanel, FailurePanel, MainMenuPanel, VideoControls, Fade (topmost)
[EventSystem]   StandaloneInputModule or InputSystemUIInputModule depending on the input backend
```

State flow: `GameState` raises `AttemptsChanged`, `StageChanged`, `StatusChanged`, `FlagsChanged`.
`DoorController`, `PuzzleManager` and the finale subscribe to `FlagsChanged`; `GameManager` turns
`Lost` into the failure screen; `UIManager` shows attempts whenever the value changes.

Scene order (Build Settings): `00_MainMenu → 01_Invitation → 02_VossLaboratory → 03_EmptyTheatre → 00_MainMenu`.

---

## 00_MainMenu
```
MainMenu (MainMenuController)
  StageFloor, BackCurtain, GlassChamber (+frame), Title (3D text)
  KeyLight (spot), Fill (point)
  CameraRig → MenuCamera (rotates 1.5°/s)
```
Menu panel is drawn by `UIManager.ShowMainMenu`. BEGIN EXPERIMENT → `GameManager.StartNewGame()`.

## 01_Invitation
```
Invitation (InvitationSequence)
  Floor, BackWall, Table (1.6 × 0.8 × 1.0, top at y 0.8)
  Envelope (0, 0.8, 0)
    EnvelopeBody            RelayInteractable "Open envelope"
    LidPivot (hinge at back edge) → Flap, WaxSeal, SealV
    VossTicket (hidden)     RelayInteractable "Examine ticket"; Front text 7314, Back text message
  KeyLight (spot), ColdFill (point)
  Player (0, 0, -0.9), look only, camera pitched 42°
```
Flow: open → flap swings 150°, ticket rises, evidence `voss_ticket` discovered → examine (InspectionController) → on exit, fade → `02_VossLaboratory`.

## 02_VossLaboratory

### Layout (top view, +Z is "north")
```
                 z=23 ┌───────────┐ ┌───────────┐ ┌───────────┐
                      │PERCEPTION │ │  REASON   │ │  MEMORY   │   rooms 8.4 × 12, height 4.5
                 z=11 └────┬──────┘ └────┬──────┘ └────┬──────┘
                        corridor       corridor       corridor    2.4 wide, z 7..11, seal triggers at z=10
                 z=7  ────┼────────────┼────────────┼────┐
  final exit ──► ┤        door x=-10   door x=0     door x=10    ├── alcove (silhouette) x 16..22
  (x=-16,z=-3)   │                  ENTRANCE HALL 32 × 14, h 5   │   leg A z -6..-3, leg B x 19..22, z -3..3
                 z=-7 ───────────────┬─────┬────────────────────┘
                                 elevator (x ±1.5, z -10..-7)   player spawn (0,0,-8.6)
```
South wall: `ExperimentTerminal` (x 4.2), `PerformanceScreen` (x −6), `FinalQuestionTerminal` (x −11.5).

### Hierarchy
```
VossLaboratory
  Entrance            hall shell, columns, trim
    Elevator          car, ElevatorDoorLeft/Right (pivots slid by LabEntranceSequence)
    ExitElevatorZone  PlayerTriggerZone → LabEntranceSequence
    ExperimentTerminal (TerminalController, monitor text)
    PerformanceScreen (VideoInvestigationController) + PerformanceScreenSurface (render-texture quad) + caption
    FinalQuestionTerminal → Screen (FinalQuestionTerminal)
    RevealProjector (spot, off until the reveal)
  HallLights          4 cold points, alcove/vestibule/elevator points, 3 Emergency_* red points (off)
  PERCEPTIONRoom      corridor + room shell, Door_PERCEPTION (DoorController, seals until PerceptionSolved),
                      SealTrigger (DoorSealTrigger), Principle (off),
                      PerceptionPuzzle, Exhibit_* ×5, HiddenREADCompartment (CompartmentDoor, READCard), lights, FeedbackLight
  REASONRoom          Door_REASON (needs ReasonUnlocked), BalanceScale (BalanceScaleController, Mask, Key),
                      BlackBox (BlackBoxController, BACKWARDSCard), EquationDisplay, AnswerTerminal (KeypadController),
                      ReasonPuzzle, lights, FeedbackLight
  MEMORYRoom          Door_MEMORY (manual: opened by MemoryDoorController), FinalTerminal (TerminalController),
                      READDisplay, BACKWARDSDisplay, MemoryPuzzle, lights
  MemoryDoorKeypad    (MemoryDoorController) beside the MEMORY door
  SilhouetteCorridor  legs A/B, VossSilhouette, WalkStart, WalkEnd, WallWriting (off), SilhouetteTrigger (VossSilhouetteEvent)
  PerformanceDiorama  (0, -60, 0): StageFloor, Backdrop, Chamber, DarkCurtain, ProjectedSilhouette, VossFigure,
                      StageSpot_*, BackstageGlow, CameraA_Audience, CameraB_Secondary (both render to a 1024×576 RT)
  FinalExit           vestibule, Door_FinalExit (manual), ExitSign (off), TheatreExitTrigger (SceneExitTrigger)
  Managers            PuzzleManager, FinalInvestigationController, FinalRevealController, GameRestartController, LabEntranceSequence
  Player              CharacterController, FirstPersonController, InspectionController, PlayerInteractor, PlayerCamera
```

### Exhibits (PERCEPTION)
Each `Exhibit_*` is rotated so local +Z points into the room. Behind the wall plane sits a dark niche;
at the plane a translucent `MirrorPane` (MirrorDisplay); in front, `Object` (pedestal + `Prop`, InspectableObject);
behind, `Reflection` (a second copy). Correct reflections are scaled `(1, 1, −1)` – a true mirror flips depth.
The impossible one (Plant) is scaled `(−1, 1, 1)` – flipped left-right instead, so its leaves lean the wrong way.

### The reconstruction
`VideoInvestigationController` steps through ten `Frame`s (Voss position, projection alpha, lights, two captions).
Camera A is the audience; Camera B stands behind the `DarkCurtain` so it sees Voss moving sideways into the wings
while the `ProjectedSilhouette` quad fills the chamber. Frames 7–8 are the blackout; frame 9 is the empty chamber.

### Progression gates
| Gate | Condition |
|---|---|
| Door PERCEPTION | always (PerceptionUnlocked) |
| Door REASON | ReasonUnlocked (set by PerceptionPuzzle) |
| Door MEMORY | keypad answer 7314 (requires MemoryUnlocked from ReasonPuzzle) |
| Rooms seal behind the player | released by that room's *Solved* flag (MEMORY: MetaCodeSolved) |
| Performance screen / final question | FinalInvestigationController.Begin() after MemoryPuzzle |
| Final exit | FinalExitUnlocked (FinalRevealController) |
| Silhouette event | PerceptionSolved && !SilhouetteEventPlayed, once |

## 03_EmptyTheatre
```
EmptyTheatre (TheatreEndingController, GameRestartController)
  House shell 28 × 34 × 10, LabDoorBehind + label, Stage (y 1, z 2..11) + steps, curtains, proscenium
  GlassChamber (0, 1, 6) → Glass, posts, VossSilhouette (off), ChamberPlaque (InspectableObject)
  Seats (grid, centre aisle), Projector (stand, body, lens, ProjectorBeam spot – off)
  CompleteSign (3D text above the proscenium, empty until the end)
  TheatreExit (x 14, z −19): DoorController (manual), ExitSign (off), vestibule, ExitZone
  StageSpot_C/L/R + ChamberGlow (start at 0 intensity), house lights, DustParticles
  ApproachZone (z −8), ChamberZone (stage front), Player (0, 0, −20.4)
```
Flow: approach → stage lights rise over 5 s → chamber zone → silhouette in the glass until the player looks away →
projector + final dialogue → exit sign, *EXPERIMENT 001 — COMPLETE*, door opens → exit zone → fade,
ending text, `GameManager.CompleteGame()`, back to the main menu.
